import java.io.Serializable;

class MessageInfo implements Serializable {
    private String message;
    private int characterCount;
    private int digitCount;

    public MessageInfo(String message, int characterCount, int digitCount) {
        this.message = message;
        this.characterCount = characterCount;
        this.digitCount = digitCount;
    }

    public String getMessage() {
        return message;
    }

    public int getCharacterCount() {
        return characterCount;
    }

    public int getDigitCount() {
        return digitCount;
    }
}