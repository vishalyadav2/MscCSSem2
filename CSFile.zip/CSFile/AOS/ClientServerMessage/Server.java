import java.io.*;
import java.net.*;

public class Server {
    public static void main(String[] args) {
        int port = 12068;

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server listening on port " + port);

            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     ObjectInputStream in = new ObjectInputStream(clientSocket.getInputStream());
                     ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream())) {

                    String message = (String) in.readObject();
                    int characterCount = 0;
                    int digitCount = 0;

                    for (char c : message.toCharArray()) {
                        if (Character.isDigit(c)) {
                            digitCount++;
                        }
                        if (Character.isLetter(c)) {
                            characterCount++;
                        }
                    }

                    MessageInfo messageInfo = new MessageInfo(message, characterCount, digitCount);
                    out.writeObject(messageInfo);

                } catch (IOException | ClassNotFoundException e) {
                    System.err.println("Error in communication with client: " + e.getMessage());
                }
            }

        } catch (IOException e) {
            System.err.println("Error starting server: " + e.getMessage());
        } 
    }
}