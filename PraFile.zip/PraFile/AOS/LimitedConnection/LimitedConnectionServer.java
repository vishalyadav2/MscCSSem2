import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Semaphore;

public class LimitedConnectionServer {

    private static final int PORT = 6018;
    private static final int MAX_CONNECTIONS = 3;
    private static final Semaphore semaphore = new Semaphore(MAX_CONNECTIONS);

    public static void main(String[] args) {
        System.out.println("Server is running on port " + PORT);
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                try {
                    semaphore.acquire(); // Acqurie a permit
                    Socket clienSocket = serverSocket.accept();
                    new Thread(new ClientHandler(clienSocket)).start();
                } catch (InterruptedException e) {
                    System.err.println("Semaphore acquisition interrupted : " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Could not start server on port " + PORT);
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {

        private final Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (clientSocket;
                    PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                        out.println("You are connected to the server!");
                        // Simulate some server processing
                        Thread.sleep(5000);
            }catch(IOException | InterruptedException e){
                System.err.println("Error handling client connection : " + e.getMessage());
            }finally{
                semaphore.release(); // Release the permit
            }
        }
    }
}