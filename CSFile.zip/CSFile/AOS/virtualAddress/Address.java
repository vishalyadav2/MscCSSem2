public class Address {
    public static void main(String [] args){
        if (args.length != 2){
            System.out.println("Usage : java Address <Page Size> <Virtual address>");
            System.exit(1);}
        int pageSize = Integer.parseInt(args[0]);
        int virtualAddress = Integer.parseInt(args[1]);
  // Validate the page size
        if (!isPowerOfTwo(pageSize) || pageSize < 1024 || pageSize > 16384){
            System.out.println("Page size must be a Power of 2 and Within the range 1024");
        System.exit(1);}
        // Calculate Page number and offset
        int pageNumber = virtualAddress / pageSize;
        int offSet = virtualAddress % pageSize;
 // print the results
        System.out.println("The address " + virtualAddress + " contains:");
        System.out.println("Page number = " + pageNumber);
        System.out.println("OffSet = " + offSet);}
// Hepler method to check if a number is apower of two
    private static boolean isPowerOfTwo(int number){
        return (number & (number - 1)) == 0; 
    }
}

//cd documents
//cd File
//cd virtualAddress
//javac Address.java
//java Address 4096 19986
