import java.io.*;
import java.net.*;
import java.util.Random;

public class QuoteServer {
    private static final int PORT = 12061;
    private static final String[] QUOTES = {
        "The only limit to our realization of tomorrow is our doubts of today. - Franklin D. Roosevelt",
        "Do not wait to strike till the iron is hot; but make it hot by striking. - William Butler Yeats",
        "Whether you think you can or think you can’t, you’re right. - Henry Ford",
        "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
        "It does not matter how slowly you go as long as you do not stop. - Confucius",
        "Life is what happens when you're busy making other plans. - John Lennon"
    };

    public static void main(String[] args) {
        System.out.println("Quote of the Day Server is running...");

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            while (true) {
                try (Socket clientSocket = serverSocket.accept();
                     PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                    
                    String quote = getRandomQuote();
                    out.println(quote);
                } catch (IOException e) {
                    System.err.println("Error handling client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Could not start server on port " + PORT);
            e.printStackTrace();
        }
    }

    private static String getRandomQuote() {
        Random random = new Random();
        int index = random.nextInt(QUOTES.length);
        return QUOTES[index];
    }
}