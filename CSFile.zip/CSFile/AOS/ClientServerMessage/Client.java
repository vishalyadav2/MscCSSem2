import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        String host = "localhost";
        int port = 12068;
        String message;
   
        if (args.length > 0) {
            message = args[0];
        } else {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter a message: ");
            try {
                message = reader.readLine();
            } catch (IOException e) {
                System.err.println("Error reading input: " + e.getMessage());
                return;
            }
        }

        try (Socket socket = new Socket(host, port);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            out.writeObject(message);

            MessageInfo messageInfo = (MessageInfo) in.readObject();

            System.out.println("Message: " + messageInfo.getMessage());
            System.out.println("Character Count: " + messageInfo.getCharacterCount());
            System.out.println("Digit Count: " + messageInfo.getDigitCount());

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error in communication with server: " + e.getMessage());
        }
    }
}
